Defender CXP Black
By RPGuere
http://rpguere.deviantart.com/art/Defender-CXP-Black-31046099

Cursorized by jacksmafia
http://jacksmafia.deviantart.com/art/Defender-Black-152042987

Downloaded @ http://www.cursors-4u.com/