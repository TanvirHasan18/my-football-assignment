Created By theblueguy07
http://theblueguy07.deviantart.com/
Downloaded @ http://www.cursors-4u.com/

======================
How To Install
======================

Right click the "(Installer).inf" file name and choose "Install"
Go to Control Panel
Then Go To Mouse
Go To "Pointers" tab
Under "Scheme" Choose "Night Daimond"
Click Apply

You can then delete the night diamond unzip folders becuase the installer has copy them into the "Cursors" Directory already in your windows computer.  These instructions were brought to you buy Cursors-4U.com