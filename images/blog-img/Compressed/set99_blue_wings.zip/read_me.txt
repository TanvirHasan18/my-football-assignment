Created by: Jani77
http://jani77.deviantart.com/

This cursor set was originally created for CursorFX.  It was converted to work with Windows XP, Vista, and Seven by Cursors-4U.com.  Also downloaded from Cursors-4U.com