MB-EvilGhost - Raw, Horror, Death Font by ModBlackmoon. [Hand-drawing + Photoshop]

INFO: 
Incl. English, European and Cyrillic letters and Numbers. May be scaled to extra large size without quality loss.

LICENSE: 
Free for personal, but Shareware for any public or commercial use. No modify!

Designed: November 2010.
Author: ModBlackmoon
WEB: modblackmoon.narod.ru / modblackmoon.deviantart.com