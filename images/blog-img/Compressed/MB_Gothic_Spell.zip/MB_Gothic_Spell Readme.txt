MB Gothic Spell - TTF Font, based on traditional gothic capital letter shapes with some metal infuences and extra ornaments [Hand-drawing + Illustrator].

INFO: 
Incl. English letters and Numbers, some most common signs, some letters from nordic languages. 

LICENSE: 
Free for personal and commercial use. For commercial use credits are required. No modify.

Designed: April 2015
Author: ModBlackmoon
WEB: modblackmoon.com / www.facebook.com/ModBlackmoon.Art