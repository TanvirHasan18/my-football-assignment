﻿=== Highlight Blue 10 Cursor Set ===

By: RIDDLER (http://www.rw-designer.com/user/70600)

Download: http://www.rw-designer.com/cursor-set/highlight-blue-10

Author's description:

There is another color that I have uploaded recently. This color is a '''Highlight Blue 10''' cursor set. This blue color has a slight purplish appearance because there is 50% of transparency. The transparency level is what makes this purple appearance, but the color itself is truly blue.

This cursor set is complete with 17 cursor roles in a 64x64 pixel size. White cursors on blue halos looks fascinating. All those cursors in this set were designed for the Windows 10 operating system.

There are two animated cursor roles. Both have a blue animated wheel. The animation from the spinning wheels are a little obscured by the blue background halo. There is nothing I can do to improve that. The blue from the spinning wheels is brighter with 100% opacity so it is still visible at close eye.

Blue halo circles are there as guide rails so that users can use this cursor set as a purpose of focusing on clickable buttons, video screens and presentations. When you need to focus on something, those cursor act as an aid to help you properly see and focus on the area you are clicking on. Enjoy this blue color.

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.