Welcome TO Unborn 8.0 Color Edition!

I hope you enjoy these 12 wonderful colors of Unborn 8.0
Each color set of cursors come with an "AutoSetup".inf file to install easy.

Just right-click the AutoSetup file, then click "install". Windows will automatically install the cursors and pop-up the mouse properties window. Go to "Pointers" menu, then press OK twice and your cursors will be set. It's that simple. I hope you enjoy these cursors as much as I made them. Thank you for downloading.

Check out my DA site for more cool stuff http://gentlemangezzy.deviantart.com/