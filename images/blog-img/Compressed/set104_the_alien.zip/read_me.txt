Created By Jalenton
http://jalentorn.deviantart.com/

Converted to work with Windows by Xav73
http://xav73.deviantart.com/