MB Forever Raw - Horror, Metalhead Font by ModBlackmoon. [Hand-drawing + Photoshop]

INFO: 
Incl. English, European letters and Numbers. May be scaled to extra large size without quality loss.
This font it something like a conclusion of what i've done before in my Arcane, Gothic Dawn and Graveyard Designs fonts, so that's why it's free. That's some kind of next level of this style - with higher quality, smooth curves... Enjoy.

LICENSE: 
Free for personal and commercial use. No modify. Don't claim it as your own.

Designed: March 2012.
Author: ModBlackmoon

WEB: 
modblackmoon.narod.ru 
modblackmoon.deviantart.com